/*
* The following code draws a 3d scene with directional light and a point light
* 
* The user should be able to use WASD, Q, and E to move, along with scroll wheel to adjust camera
* speed and P to switch between perspective and orthographic views.
* 
* Code adapted from learnopengl
* https://learnopengl.com/code_viewer_gh.php?code=src/2.lighting/6.multiple_lights/multiple_lights.cpp
* Aimed for minimum necessary comments (relying heavily on meaningful variable/function names)
*/

#include <glad/glad.h> 
#include <GLFW/glfw3.h>
//#include <Cylinder.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <iostream>
#include <vector>

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow* window);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);


const char* vertexShaderSource =
"#version 330 core\n"

"layout (location = 0) in vec3 aPos;\n"
"layout (location = 1) in vec3 aNormal;\n"
"layout (location = 2) in vec2 aTextureCoordinate;\n"

"out vec3 FragPos;\n"
"out vec3 Normal;\n"
"out vec2 textureCoordinate;\n"

"uniform mat4 view;\n"
"uniform mat4 projection;\n"
"uniform mat4 modelRotate;\n"
"uniform mat4 modelScale;\n"
"uniform mat4 modelTranslate;\n"

"void main()\n"
"{\n"
"   mat4 model = modelTranslate * modelRotate* modelScale ;\n" // Model transformations

"   FragPos = vec3(model * vec4(aPos, 1.0));\n"
"   Normal = mat3(transpose(inverse(model))) * aNormal;\n"
"   gl_Position = projection * view * vec4(FragPos, 1.0);\n"
"   textureCoordinate = vec2(aTextureCoordinate.x, aTextureCoordinate.y);\n"
"}\n\0";

const char* fragmentShaderSource =
"#version 330 core\n"

"in vec3 FragPos;\n"
"in vec3 Normal;\n"
"in vec2 textureCoordinate;\n"
"out vec4 FragColor;\n"

"struct Material {\n"
"   sampler2D diffuse;\n"
"   sampler2D specular;\n"
"   float shininess;\n"
"};\n"

"struct DirLight {\n"
"    vec3 direction;\n"
"    vec3 ambient;\n"
"    vec3 diffuse;\n"
"    vec3 specular;\n"
"};\n"

"struct PointLight {\n"
"   vec3 position;\n"
"   vec3 lightColor;\n"
"   float constant;\n"
"   float linear;\n"
"   float quadratic;\n"
"   vec3 ambient;\n"
"   vec3 diffuse;\n"
"   vec3 specular;\n"
"};\n"

"#define NR_POINT_LIGHTS 1\n"
"uniform PointLight pointLights[NR_POINT_LIGHTS];\n"
"uniform vec3 viewPos;\n"
"uniform sampler2D ourTexture;\n"
"uniform Material material;\n"
"uniform DirLight dirLight;\n"

"vec3 CalcDirLight(DirLight light, vec3 normal, vec3 viewDir);\n"
"vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir);\n"

"void main()\n"
"{\n"
"   vec3 norm = normalize(Normal);\n"
"   vec3 viewDir = normalize(viewPos - FragPos);\n"
"   vec3 result = CalcDirLight(dirLight, norm, viewDir);\n"
"   for (int i = 0; i < NR_POINT_LIGHTS; i++)\n"
"        result += CalcPointLight(pointLights[i], norm, FragPos, viewDir);\n"
"   FragColor = vec4(result, 1.0);\n"
"}\n"

"vec3 CalcDirLight(DirLight light, vec3 normal, vec3 viewDir)\n"
"{\n"
"    vec3 lightDir = normalize(-light.direction);\n"
    // Diffuse shading
"    float diff = max(dot(normal, lightDir), 0.0);\n"
    // Specular shading
"    vec3 reflectDir = reflect(-lightDir, normal);\n"
"    float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);\n"
    // Combine results
"    vec3 ambient = light.ambient * vec3(texture(ourTexture, textureCoordinate));\n"
"    vec3 diffuse = light.diffuse * diff * vec3(texture(ourTexture, textureCoordinate));\n"
"    vec3 specular = light.specular * spec * vec3(texture(ourTexture, textureCoordinate));\n"
"    return (ambient + diffuse + specular);\n"
"}\n"

// Calculates the color when using a point light.
"vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir)\n"
"{\n"
"   vec3 lightDir = normalize(light.position - fragPos);\n"
"   float diff = max(dot(normal, lightDir), 0.0);\n" // Diffuse shading
// Specular shading
"   vec3 reflectDir = reflect(-lightDir, normal);\n"
"   float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);\n"
// Attenuation
"   float distance = length(light.position - fragPos);\n"
"   float attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));\n"
// Combine results
"   vec3 color = light.lightColor;\n"
"   vec3 ambient = light.ambient * color * vec3(texture(ourTexture, textureCoordinate));\n"
"   vec3 diffuse = light.diffuse * diff * color * vec3(texture(ourTexture, textureCoordinate));\n"
"   vec3 specular = light.specular * spec * color * vec3(texture(ourTexture, textureCoordinate));\n"
"   ambient *= attenuation;\n"
"   diffuse *= attenuation;\n"
"   specular *= attenuation;\n"
"   return (ambient + diffuse + specular);\n"
"}\n\0";


using namespace std;

// Window dimension settings
const unsigned int SCR_WIDTH = 1600;
const unsigned int SCR_HEIGHT = 900;

// Timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;

// Camera attributes
glm::vec3 cameraPos = glm::vec3(0.0f, 4.0f, 6.0f); //Slight offset (above and away) from our object for initial camera position
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f); //Set our initial camera direction to face our object
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f); //Define our "up" direction
bool firstMouse = true;
float yaw = -90.0f;	// yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right so we initially rotate a bit to the left.
float pitch = 0.0f;
float lastX = SCR_WIDTH / 2.0;
float lastY = SCR_HEIGHT / 2.0;
float customCameraSpeed = 2.5f; //Initial camera speed that can be adjusted with scroll wheel
float projectionState = 1; //Determines whether view is perspective (1) or orthographic (-1)


int main()
{
    // Initializing our window options with the opengl version we will be using
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // Instantiating our window
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Module 8 Assignment - 3d Scene with lighting", NULL, NULL);

    // Verifying our window was successfully instantiated and quitting the program if not
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    // Registering our callback functions
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);

    // Tell GLFW to capture our mouse
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // Ensure GLAD was able to initialize which allows for loading all function pointers
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // Enable depth testing to help ensure shapes are overlaid properly
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_TEXTURE_2D);

    // Variables used for error reporting when compiling and linking shaders    
    int  success;
    char infoLog[512];

    // Creating and compiling vertex shader
    unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
    glCompileShader(vertexShader);
    // Checking for compile errors
    glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
    }

    // Creating and compiling fragment shader
    unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
    glCompileShader(fragmentShader);
    // Checking for compile errors
    glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
    }

    // Linking shaders to program
    unsigned int shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    // Checking for link errors
    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
    }

    // Cleaning up objects after we're finished linking them
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    //Set our light positions
    glm::vec3 pointLightPositions[] = {
        // Key light at lamp position
        glm::vec3(-6.0f, 3.5f, -4.0f),
        // Fill light
        //glm::vec3(-2.2f, 4.5f, 1.5f)
    };

    //Define all of our vertices for our objects
    //------------------------------------------
    float planeVertices[] = {
        //Position        //Normal          //Texture
        0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
        1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,
        1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f,
        1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f,
        0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,
        0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f
    };
    float boxVertices[] = {
        //Position           //Normal           //Texture
        //Back face
        -0.5f, -0.5f, -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
         0.5f, -0.5f, -0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,
         0.5f,  0.5f, -0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,
         0.5f,  0.5f, -0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,
        -0.5f,  0.5f, -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
        //Front face
        -0.5f, -0.5f,  0.5f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
         0.5f, -0.5f,  0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f,
         0.5f,  0.5f,  0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,
         0.5f,  0.5f,  0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,
        -0.5f,  0.5f,  0.5f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
        //Left face
        -0.5f,  0.5f,  0.5f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
        -0.5f,  0.5f, -0.5f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f,
        -0.5f,  0.5f,  0.5f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
        //Right face
         0.5f,  0.5f,  0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
         0.5f,  0.5f, -0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f,
         0.5f, -0.5f, -0.5f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f,
         0.5f, -0.5f, -0.5f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f,
         0.5f, -0.5f,  0.5f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f,
         0.5f,  0.5f,  0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
        //Bottom face
        -0.5f, -0.5f, -0.5f, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f,
         0.5f, -0.5f, -0.5f, 0.0f, -1.0f, 0.0f, 1.0f, 1.0f,
         0.5f, -0.5f,  0.5f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,
         0.5f, -0.5f,  0.5f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,
        -0.5f, -0.5f,  0.5f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f,
        -0.5f, -0.5f, -0.5f, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f,
        //Top face
        -0.5f,  0.5f, -0.5f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,
         0.5f,  0.5f, -0.5f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f,
         0.5f,  0.5f,  0.5f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,
         0.5f,  0.5f,  0.5f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,
        -0.5f,  0.5f,  0.5f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
        -0.5f,  0.5f, -0.5f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f
    };
    float pyramidVertices[] = {
        //(Section position descriptions are after 90 degree rotation is applied)
        //Base 1/2                                           
         0.5f,  0.5f,  0.0f, 0.0f, -1.0f, 0.0f, 1.0f, 1.0f,
         0.5f, -0.5f,  0.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,
        -0.5f,  0.5f,  0.0f, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f,
         //Base 2/2
        -0.5f,  0.5f,  0.0f, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f,
        -0.5f, -0.5f,  0.0f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f,
         0.5f, -0.5f,  0.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,
         //Right face
         0.5f,  0.5f,  0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f,
         0.5f, -0.5f,  0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
         0.0f,  0.0f, -0.5f, 1.0f, 0.0f, 0.0f, 0.5f, 0.5f,
         //Front face
         0.5f, -0.5f,  0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f,
        -0.5f, -0.5f,  0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
         0.0f,  0.0f, -0.5f, 0.0f, 0.0f, 1.0f, 0.5f, 0.5f,
         //Left face
        -0.5f, -0.5f,  0.0f, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f,
        -0.5f,  0.5f,  0.0f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f,
         0.0f,  0.0f, -0.5f, -1.0f, 0.0f, 0.0f, 0.5f, 0.5f,
         //Back face
         0.5f,  0.5f,  0.0f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,
        -0.5f,  0.5f,  0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,
         0.0f,  0.0f, -0.5f, 0.0f, 0.0f, -1.0f, 0.5f, 0.5f
    };

    // Declare our VBO and VAO's
    unsigned int VBO, VAOplane, VAObox, VAOpyramid;
    // Initialize our vertex array and set our vertex attributes for our plane
    //------------------------------------------------------------------------
    glGenVertexArrays(1, &VAOplane);
    glGenBuffers(1, &VBO);
    // Bind the vertex array for our plane
    glBindVertexArray(VAOplane);
    // Bind buffer object to array and set buffer object data
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), planeVertices, GL_STATIC_DRAW);
    // Position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // Normal attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // Texture coordinate attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);
    // Initialize our vertex array and set our vertex attributes for our box
    //----------------------------------------------------------------------
    glGenVertexArrays(1, &VAObox);
    glGenBuffers(1, &VBO);
    // Bind the vertex array for our box
    glBindVertexArray(VAObox);
    // Bind buffer object to array and set buffer object data
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(boxVertices), boxVertices, GL_STATIC_DRAW);
    // Position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // Normal attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // Texture coordinate attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);
    // Initialize our vertex array and set our vertex attributes for our pyramid / lamp shade
    //---------------------------------------------------------------------------------------
    glGenVertexArrays(1, &VAOpyramid);
    glGenBuffers(1, &VBO);
    // Bind the vertex array for our box
    glBindVertexArray(VAOpyramid);
    // Bind buffer object to array and set buffer object data
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(pyramidVertices), pyramidVertices, GL_STATIC_DRAW);
    // Position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // Normal attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // Texture coordinate attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // Load and create our textures
    // ----------------------------
    // Texture "0" - wood floor
    // ------------------------
    unsigned int woodFloor;
    glGenTextures(1, &woodFloor);
    glBindTexture(GL_TEXTURE_2D, woodFloor);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// set texture wrapping to GL_REPEAT (default wrapping method)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    int width, height, nrChannels;
    unsigned char* data = stbi_load("woodFloor.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    // Texture "1" - wood table
    // ------------------------
    unsigned int woodtable;
    glGenTextures(1, &woodtable);
    glBindTexture(GL_TEXTURE_2D, woodtable);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// set texture wrapping to GL_REPEAT (default wrapping method)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    data = stbi_load("woodtable.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    // Texture "2" - lamp shade
    // ------------------------
    unsigned int lampTexture;
    glGenTextures(1, &lampTexture);
    glBindTexture(GL_TEXTURE_2D, lampTexture);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// set texture wrapping to GL_REPEAT (default wrapping method)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    data = stbi_load("lamp.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    // Texture "3" - wood leg
    // ----------------------
    unsigned int woodLeg;
    glGenTextures(1, &woodLeg);
    glBindTexture(GL_TEXTURE_2D, woodLeg);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// set texture wrapping to GL_REPEAT (default wrapping method)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    data = stbi_load("woodLeg.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    // Texture "4" - lamp stand
    // ------------------------
    unsigned int lampStand;
    glGenTextures(1, &lampStand);
    glBindTexture(GL_TEXTURE_2D, lampStand);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// set texture wrapping to GL_REPEAT (default wrapping method)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load image, create texture and generate mipmaps
    data = stbi_load("metal.jpg", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);

    //Wireframe mode
    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

    // Render loop
    //------------
    while (!glfwWindowShouldClose(window))
    {
        // Per-frame time logic
        // --------------------
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        // Check for user input and close window if user presses escape
        processInput(window);

        // Set background color to black
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        // Apply background color
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Activate shaders
        glUseProgram(shaderProgram);

        // Create world view and projection
        //---------------------------------
        glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        glm::mat4 projection = glm::mat4(1.0f);
        // Using a branch to allow the user to toggle projection between perspective and orthographic
        if (projectionState == 1) {
            projection = glm::perspective(glm::radians(45.0f), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        }
        else if (projectionState == -1) {
            //projection = glm::ortho(0.0f, (float)SCR_WIDTH, 0.0f, (float)SCR_HEIGHT, 0.1f, 100.0f);
            projection = glm::ortho(-2.0f, 2.0f, -1.5f, 1.5f, 0.1f, 100.0f);
        }
        unsigned int projectionLoc = glGetUniformLocation(shaderProgram, "projection");
        unsigned int viewLoc = glGetUniformLocation(shaderProgram, "view");
        glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));

        // Set our lights
        // --------------
        // Directional light
        glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.direction"), -0.2f, -1.0f, -0.3f);
        glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.ambient"), 0.05f, 0.05f, 0.05f);
        glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.diffuse"), 0.3f, 0.3f, 0.3f);
        glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.specular"), 0.5f, 0.5f, 0.5f);
        // Point light
        glUniform3f(glGetUniformLocation(shaderProgram, "pointLights[0].position"), pointLightPositions[0].x, pointLightPositions[0].y, pointLightPositions[0].z);
        glUniform3f(glGetUniformLocation(shaderProgram, "pointLights[0].ambient"), 0.05f, 0.05f, 0.05f);
        glUniform3f(glGetUniformLocation(shaderProgram, "pointLights[0].diffuse"), 0.3f, 0.3f, 0.3f);
        glUniform3f(glGetUniformLocation(shaderProgram, "pointLights[0].specular"), 0.5f, 0.5f, 0.5f);
        glUniform3f(glGetUniformLocation(shaderProgram, "pointLights[0].lightColor"), 1.0f, 0.1f, 1.0f);
        glUniform1f(glGetUniformLocation(shaderProgram, "pointLights[0].constant"), 1.0f);
        glUniform1f(glGetUniformLocation(shaderProgram, "pointLights[0].linear"), 0.09);
        glUniform1f(glGetUniformLocation(shaderProgram, "pointLights[0].quadratic"), 0.032);

        // Place our objects
        // -----------------

        // Floor plane
        // -----------
        // Bind textures on corresponding texture units
        glUniform1i(glGetUniformLocation(shaderProgram, "ourTexture"), 0);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, woodFloor);
        // Set transformations and send to shader program
        glm::mat4 modelRotate = glm::mat4(1.0f);
        glm::mat4 modelScale = glm::mat4(1.0);
        glm::mat4 modelTranslate = glm::mat4(1.0f);
        modelScale = glm::scale(modelScale, glm::vec3(25.0f, 1.0f, 25.0f));
        modelTranslate = glm::translate(modelTranslate, glm::vec3(-12.5f, 0.0f, -12.5f));
        unsigned int modelRotateLoc = glGetUniformLocation(shaderProgram, "modelRotate");
        unsigned int modelScaleLoc = glGetUniformLocation(shaderProgram, "modelScale");
        unsigned int modelTranslateLoc = glGetUniformLocation(shaderProgram, "modelTranslate");
        // Pass transformation matrices to the shader
        glUniformMatrix4fv(modelRotateLoc, 1, GL_FALSE, glm::value_ptr(modelRotate));
        glUniformMatrix4fv(modelScaleLoc, 1, GL_FALSE, glm::value_ptr(modelScale));
        glUniformMatrix4fv(modelTranslateLoc, 1, GL_FALSE, glm::value_ptr(modelTranslate));
        // Draw plane
        glBindVertexArray(VAOplane);
        glDrawArrays(GL_TRIANGLES, 0, 6);

        // Tabletop
        // --------
        // Bind textures on corresponding texture units
        glUniform1i(glGetUniformLocation(shaderProgram, "ourTexture"), 1);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, woodtable);
        // Set transformations and send to shader program
        modelScale = glm::mat4(1.0);
        modelTranslate = glm::mat4(1.0f);
        modelScale = glm::scale(modelScale, glm::vec3(6.0f, 0.1f, 2.0f));
        modelTranslate = glm::translate(modelTranslate, glm::vec3(0.0f, 1.55f, 0.0f));
        // Pass transformation matrices to the shader
        glUniformMatrix4fv(modelScaleLoc, 1, GL_FALSE, glm::value_ptr(modelScale));
        glUniformMatrix4fv(modelTranslateLoc, 1, GL_FALSE, glm::value_ptr(modelTranslate));
        // Draw our table
        glBindVertexArray(VAObox);
        glDrawArrays(GL_TRIANGLES, 0, 36);

        glm::vec3 tableLegPositions[] = {
            glm::vec3(-2.75f, 0.75f, 0.75f),
            glm::vec3(-2.75f, 0.75f, -0.75f),
            glm::vec3(2.75f, 0.75f, -0.75f),
            glm::vec3(2.75f, 0.75f, 0.75f)
        };

        // Table legs
        //-----------
        for (int i = 0; i < 4; i++) {
            // Bind textures on corresponding texture units
            glUniform1i(glGetUniformLocation(shaderProgram, "ourTexture"), 3);
            glActiveTexture(GL_TEXTURE3);
            glBindTexture(GL_TEXTURE_2D, woodLeg);
            // Set transformations and send to shader program
            modelScale = glm::mat4(1.0);
            modelTranslate = glm::mat4(1.0f);
            modelScale = glm::scale(modelScale, glm::vec3(0.1f, 1.5f, 0.1f));
            modelTranslate = glm::translate(modelTranslate, tableLegPositions[i]);
            // Pass transformation matrices to the shader
            glUniformMatrix4fv(modelScaleLoc, 1, GL_FALSE, glm::value_ptr(modelScale));
            glUniformMatrix4fv(modelTranslateLoc, 1, GL_FALSE, glm::value_ptr(modelTranslate));
            // Draw table leg 1
            glBindVertexArray(VAObox);
            glDrawArrays(GL_TRIANGLES, 0, 36);
        }
        
        // Lamp shade
        // ----------
        // Bind textures on corresponding texture units
        glUniform1i(glGetUniformLocation(shaderProgram, "ourTexture"), 2);
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, lampTexture);
        // Set transformations and send to shader program
        modelRotate = glm::mat4(1.0f);
        modelScale = glm::mat4(1.0);
        modelTranslate = glm::mat4(1.0f);
        modelRotate = glm::rotate(modelRotate, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f)); //Rotating 90 degrees so our pyramid is upright
        modelScale = glm::scale(modelScale, glm::vec3(0.95f, 1.0f, 0.95f));
        modelTranslate = glm::translate(modelTranslate, glm::vec3(-6.0f, 3.5f, -4.0f));
        // Pass transformation matrices to the shader
        glUniformMatrix4fv(modelRotateLoc, 1, GL_FALSE, glm::value_ptr(modelRotate));
        glUniformMatrix4fv(modelScaleLoc, 1, GL_FALSE, glm::value_ptr(modelScale));
        glUniformMatrix4fv(modelTranslateLoc, 1, GL_FALSE, glm::value_ptr(modelTranslate));
        // Draw lamp shade
        glBindVertexArray(VAOpyramid);
        glDrawArrays(GL_TRIANGLES, 0, 18);

        // Lamp stand
        // ----------
        // Bind textures on corresponding texture units
        glUniform1i(glGetUniformLocation(shaderProgram, "ourTexture"), 4);
        glActiveTexture(GL_TEXTURE4);
        glBindTexture(GL_TEXTURE_2D, lampStand);
        // Set transformations and send to shader program
        modelRotate = glm::mat4(1.0f);
        modelScale = glm::mat4(1.0);
        modelTranslate = glm::mat4(1.0f);
        modelScale = glm::scale(modelScale, glm::vec3(0.05f, 3.5f, 0.05f));
        modelTranslate = glm::translate(modelTranslate, glm::vec3(-6.0f, 1.75f, -4.0f));
        glUniformMatrix4fv(modelRotateLoc, 1, GL_FALSE, glm::value_ptr(modelRotate));
        glUniformMatrix4fv(modelScaleLoc, 1, GL_FALSE, glm::value_ptr(modelScale));
        glUniformMatrix4fv(modelTranslateLoc, 1, GL_FALSE, glm::value_ptr(modelTranslate));
        // Draw lamp stand
        glBindVertexArray(VAObox);
        glDrawArrays(GL_TRIANGLES, 0, 36);

        // Lamp base
        // ---------
        // Bind textures on corresponding texture units
        glUniform1i(glGetUniformLocation(shaderProgram, "ourTexture"), 4);
        glActiveTexture(GL_TEXTURE4);
        glBindTexture(GL_TEXTURE_2D, lampStand);
        // Set transformations and send to shader program
        modelScale = glm::mat4(1.0);
        modelTranslate = glm::mat4(1.0f);
        modelScale = glm::scale(modelScale, glm::vec3(0.5f, 0.1f, 0.5f));
        modelTranslate = glm::translate(modelTranslate, glm::vec3(-6.0f, 0.05f, -4.0f));
        glUniformMatrix4fv(modelScaleLoc, 1, GL_FALSE, glm::value_ptr(modelScale));
        glUniformMatrix4fv(modelTranslateLoc, 1, GL_FALSE, glm::value_ptr(modelTranslate));
        // Draw lamp base
        glBindVertexArray(VAObox);
        glDrawArrays(GL_TRIANGLES, 0, 36);

        
        // Chair legs
        //-----------
        glm::vec3 chairLegPositions[] = {
            glm::vec3(-0.5f, 0.75f, 3.0f),
            glm::vec3(-0.5f, 0.5f, 2.0f),
            glm::vec3(0.5f, 0.5f,  2.0f),
            glm::vec3(0.5f, 0.75f, 3.0f)
        };

        glm::vec3 chairLegScales[] = {
            glm::vec3(0.1f, 2.5f, 0.1f),
            glm::vec3(0.1f, 1.0f, 0.1f),
            glm::vec3(0.1f, 1.0f, 0.1f),
            glm::vec3(0.1f, 2.5f, 0.1f)
        };

        for (int i = 0; i < 4; i++) {
            // Bind textures on corresponding texture units
            glUniform1i(glGetUniformLocation(shaderProgram, "ourTexture"), 3);
            glActiveTexture(GL_TEXTURE3);
            glBindTexture(GL_TEXTURE_2D, woodLeg);
            // Set transformations and send to shader program
            modelScale = glm::mat4(1.0);
            modelTranslate = glm::mat4(1.0f);
            modelRotate = glm::mat4(1.0f);
            modelScale = glm::scale(modelScale, chairLegScales[i]);
            modelTranslate = glm::translate(modelTranslate, chairLegPositions[i]);
            //modelRotate = glm::rotate(modelRotate, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
            // Pass transformation matrices to the shader
            glUniformMatrix4fv(modelScaleLoc, 1, GL_FALSE, glm::value_ptr(modelScale));
            glUniformMatrix4fv(modelTranslateLoc, 1, GL_FALSE, glm::value_ptr(modelTranslate));
            // Draw table leg 1
            glBindVertexArray(VAObox);
            glDrawArrays(GL_TRIANGLES, 0, 36);
        }

        // Chair seat
        // Bind textures on corresponding texture units
        glUniform1i(glGetUniformLocation(shaderProgram, "ourTexture"), 1);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, woodtable);
        // Set transformations and send to shader program
        modelScale = glm::mat4(1.0);
        modelTranslate = glm::mat4(1.0f);
        modelScale = glm::scale(modelScale, glm::vec3(1.25f, 0.1f, 1.2f));
        modelTranslate = glm::translate(modelTranslate, glm::vec3(0.0f, 1.0f, 2.4f));
        glUniformMatrix4fv(modelScaleLoc, 1, GL_FALSE, glm::value_ptr(modelScale));
        glUniformMatrix4fv(modelTranslateLoc, 1, GL_FALSE, glm::value_ptr(modelTranslate));
        // Draw chair seat
        glBindVertexArray(VAObox);
        glDrawArrays(GL_TRIANGLES, 0, 36);

        // Chair backrest
        // Bind textures on corresponding texture units
        glUniform1i(glGetUniformLocation(shaderProgram, "ourTexture"), 1);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, woodtable);
        // Set transformations and send to shader program
        modelRotate = glm::mat4(1.0);
        modelScale = glm::mat4(1.0);
        modelTranslate = glm::mat4(1.0f);
        modelRotate = glm::rotate(modelRotate, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f)); //Rotating 90 degrees so our pyramid is upright
        modelScale = glm::scale(modelScale, glm::vec3(1.25f, 0.1f, 0.5f));
        modelTranslate = glm::translate(modelTranslate, glm::vec3(0.0f, 1.8f, 2.9f));
        glUniformMatrix4fv(modelRotateLoc, 1, GL_FALSE, glm::value_ptr(modelRotate));
        glUniformMatrix4fv(modelScaleLoc, 1, GL_FALSE, glm::value_ptr(modelScale));
        glUniformMatrix4fv(modelTranslateLoc, 1, GL_FALSE, glm::value_ptr(modelTranslate));
        // Draw chair backrest
        glBindVertexArray(VAObox);
        glDrawArrays(GL_TRIANGLES, 0, 36);
        

        // Swap buffers and poll IO events
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // Cleanup by deleting all of our array and buffer objects and deleting our shaders
    glDeleteVertexArrays(1, &VAOplane);
    glDeleteVertexArrays(1, &VAObox);
    glDeleteBuffers(1, &VBO);
    glDeleteProgram(shaderProgram);

    // Terminate glfw and clear all allocated glfw resources
    glfwTerminate();
    return 0;
}



// Called when user or OS resizes window
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // Ensures viewport matches window size
    glViewport(0, 0, width, height);
}

// Quit the program if user presses the escape key
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    float cameraSpeed = customCameraSpeed * deltaTime;
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraUp;

    // Toggle between perspective (1) and orthographic (-1)
    // Initialized to perspective
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        projectionState *= -1;
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top
    lastX = xpos;
    lastY = ypos;

    float sensitivity = 0.1f; // change this value to your liking
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    yaw += xoffset;
    pitch += yoffset;

    // make sure that when pitch is out of bounds, screen doesn't get flipped
    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;

    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    customCameraSpeed += (float)yoffset;
    // Setting a min/max speed and ensuring sensitivity doesn't get flipped if value is negative
    if (customCameraSpeed < 1.0f)
        customCameraSpeed = 1.0f;
    if (customCameraSpeed > 45.0f)
        customCameraSpeed = 45.0f;
}